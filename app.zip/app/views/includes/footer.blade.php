<table class="show-product">
              <tr>
                  <td>
                      <a href="{{ URL::route('kontakti')}}">Kontakti</a>
                  </td>
                  <td>
                      <a href="{{ URL::route('cenas')}}">Cenas</a>
                  </td>
                  <td>
                      <a href="{{ URL::route('iespejas')}}">Iespējas</a>
                  </td>
              </tr>
          </table>