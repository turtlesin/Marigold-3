Hello {{ $username }} ,<br />

It seem like you requested a new password. If you did not request new password ignore this e-mail<br />

New password: {{ $password }}<br /> <br />


To activate new password use the following link.<br />
---<br />
{{ $link }}<br/>
---