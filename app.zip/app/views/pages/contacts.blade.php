@extends('layout.main')

@section('content')

 
<div id="antiprimary">
    
        <div class="entry-heading"><div class="entry-center">Kontakti</div></div>
<hr>
        <table class="show-first">
        <tr>
            <td>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2177.3585743816684!2d24.089634899999986!3d56.92552190000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46eed036765f4753%3A0xe99bc4cae2a1b8fc!2zVmllbsSrYmFzIGdhdHZlIDI5LCBaZW1nYWxlcyBwcmlla8WhcGlsc8STdGEsIFLEq2dhLCBMVi0xMDA0!5e0!3m2!1slv!2slv!4v1432324021387" 
                        width="550" height="400" frameborder="0" style="border:0"></iframe>
            </td>
            <td>
                <table class="show-first">
                    <tr>
                        <td>
                            <p>Telefona Nr: 29175363</p>
                        </td>
                        <td>
                            <p>E-pasts: sbimage@inbox.lv</p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>Adrese: Vienības gatve 29, Rīga</p>
                        </td>
                        <td>
                            <p>Darba laiks: P. O. T. C. P. 10:00 - 17:00</p>
                        </td>
                    </tr>
                </table>
        </tr>
    </table>
</div>
    <hr style="height:5pt; visibility:hidden;" />
      <!--Latvju rakstu sadaļas beigas -->
      <!-- -->
      <footer>
          @include('includes.footer')
</footer>
@stop