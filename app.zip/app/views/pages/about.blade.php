@extends('layout.main')

@section('content')

<div class="entry-heading"><div class="entry-center">Par mums</div></div>
<hr>
<div id="primary">
<table class="show-product">
    <tr> 
        <td>
<p>Uzņēmums "Marigold" piedāvā uzņēmumiem un individuālajiem klientiem izšūšanas pakalpojumus uz T-krekliem, cepurēm, dvieļiem utt. 
    ar logo, vārdiem, interesantiem uzrakstiem, kā arī logo izšūšanu uz skolēnu formām un vārdus uz sporta fomām utt.</p>
        </td>
    </tr>
</table>
</div>
<hr style="height:115pt; visibility:hidden;" />
      <!--Latvju rakstu sadaļas beigas -->
      <!-- -->
      <footer>
          @include('includes.footer')
</footer>
@stop